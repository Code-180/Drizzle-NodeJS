//++++++++++++++++++++++++++++++++++++++++++
//Inport
//++++++++++++++++++++++++++++++++++++++++++
const mysql = require('mysql2');
const express = require('express');
const bodyParser = require('body-parser');
var { eq, lt, lte, gt, gte, ne, and, or, desc,sum } = require('drizzle-orm')
//++++++++++++++++++++++++++++++++++++++++++
//DB Connection And Dazzel ORM
//++++++++++++++++++++++++++++++++++++++++++
const db = require('./db/db');
//++++++++++++++++++++++++++++++++++++++++++
//Sechema
//++++++++++++++++++++++++++++++++++++++++++
let { users } = require("./db/schema/user");
let { products } = require("./db/schema/product");
//++++++++++++++++++++++++++++++++++++++++++
const app = express();
app.use(bodyParser.json());
//++++++++++++++++++++++++++++++++++++++++++
//Product Route
//++++++++++++++++++++++++++++++++++++++++++
//Select with all columns
//++++++++++++++++++++++++++++++++++++++++++
app.get('/product-all-columns', async (req, res) => {
  const result = await db.select().from(products);
  return res.send(result);
});
//++++++++++++++++++++++++++++++++++++++++++
//Partial select
//++++++++++++++++++++++++++++++++++++++++++
app.get('/product-partial-select', async (req, res) => {
  const result = await db.select({
    id: products.id, title: products.title,
  }).from(products);
  return res.send(result);
});
//++++++++++++++++++++++++++++++++++++++++++
//Filtering Equal To
//++++++++++++++++++++++++++++++++++++++++++
app.get('/product-equalTo', async (req, res) => {
  const result = await db.select().from(products).where(eq(products.price, 2500));
  return res.send(result);
});
//++++++++++++++++++++++++++++++++++++++++++
//Filtering Less Then
//++++++++++++++++++++++++++++++++++++++++++
app.get('/product-lessThen', async (req, res) => {
  const result = await db.select().from(products).where(lt(products.discounted_price, 2500));
  return res.send(result);
});
//++++++++++++++++++++++++++++++++++++++++++
//Filtering Less Then Equalto
//++++++++++++++++++++++++++++++++++++++++++
app.get('/product-lessThenQualTo', async (req, res) => {
  const result = await db.select().from(products).where(lte(products.price, 2500));
  return res.send(result);
});
//++++++++++++++++++++++++++++++++++++++++++
//Filtering Grater Then
//++++++++++++++++++++++++++++++++++++++++++
app.get('/product-graterThen', async (req, res) => {
  const result = await db.select().from(products).where(gt(products.price, 100));
  return res.send(result);
});
//++++++++++++++++++++++++++++++++++++++++++
//Filtering Grater Then Equalto
//++++++++++++++++++++++++++++++++++++++++++
app.get('/product-graterThenEqualto', async (req, res) => {
  const result = await db.select().from(products).where(gte(products.price, 200));
  return res.send(result);
});
//++++++++++++++++++++++++++++++++++++++++++
//Filtering Grater Then Equalto
//++++++++++++++++++++++++++++++++++++++++++
app.get('/product-notEqualto', async (req, res) => {
  const result = await db.select().from(products).where(ne(products.price, 200));
  return res.send(result);
});
//++++++++++++++++++++++++++++++++++++++++++
//Filtering By Own Coloum
//++++++++++++++++++++++++++++++++++++++++++
app.get('/product-byOwnColoum', async (req, res) => {
  const result = await db.select().from(products).where(ne(products.id, 1));
  return res.send(result);
});
//++++++++++++++++++++++++++++++++++++++++++
//Combining Filters With And
//++++++++++++++++++++++++++++++++++++++++++
app.get('/product-combind-and-filter', async (req, res) => {
  const result = await db.select().from(products).where(and(eq(products.id, 2), eq(products.price, 2500)));
  return res.send(result);
});
//++++++++++++++++++++++++++++++++++++++++++
//Combining Filters With OR
//++++++++++++++++++++++++++++++++++++++++++
app.get('/product-combind-or-filter', async (req, res) => {
  const result = await db.select().from(products).where(or(eq(products.id, 2), eq(products.price, 2500)));
  return res.send(result);
});
//++++++++++++++++++++++++++++++++++++++++++
//Distinct ALL
//++++++++++++++++++++++++++++++++++++++++++
app.get('/product-distinct', async (req, res) => {
  const result = await db.selectDistinct().from(products).orderBy(products.id, products.title);
  return res.send(result);
});
//++++++++++++++++++++++++++++++++++++++++++
//Distinct With Specific Build
//++++++++++++++++++++++++++++++++++++++++++
app.get('/product-distinct-by-field', async (req, res) => {
  const result = await db.selectDistinct({ title_slug: products.title_slug }).from(products).orderBy(products.title_slug)
  return res.send(result);
});
//++++++++++++++++++++++++++++++++++++++++++
//Limit & offset
//++++++++++++++++++++++++++++++++++++++++++
app.get('/product-limit-offset', async (req, res) => {
  //const result = await db.select().from(products).limit(10);
  const result = await db.select().from(products).limit(10).offset(0);
  return res.send(result);
});
//++++++++++++++++++++++++++++++++++++++++++
//Order By
//++++++++++++++++++++++++++++++++++++++++++
app.get('/product-order-by', async (req, res) => {
  //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  // order by multiple fields
  //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  //const result =  await db.select().from(products).orderBy(products.title, products.price);
  //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  //const result = await db.select().from(products).orderBy(products.price);
  const result = await db.select().from(products).orderBy(desc(products.price));
  return res.send(result);
});
//++++++++++++++++++++++++++++++++++++++++++
//Sum
//++++++++++++++++++++++++++++++++++++++++++
app.get('/product-sum', async (req, res) => {
  const result = await db.select({ priceTotal: sum(products.price) }).from(products);
  return res.send(result);
});
//++++++++++++++++++++++++++++++++++++++++++
//Left Join
//++++++++++++++++++++++++++++++++++++++++++
app.get('/product-left-join', async (req, res) => {
  const result = await db.select().from(users).leftJoin(products, eq(users.id, products.user_id))
  return res.send(result);
});
//++++++++++++++++++++++++++++++++++++++++++
//Right Join
//++++++++++++++++++++++++++++++++++++++++++
app.get('/product-right-join', async (req, res) => {
  const result = await db.select().from(users).rightJoin(products, eq(users.id, products.user_id))
  return res.send(result);
});
//++++++++++++++++++++++++++++++++++++++++++
//Inner Join
//++++++++++++++++++++++++++++++++++++++++++
app.get('/product-inner-join', async (req, res) => {
  const result = await db.select().from(users).innerJoin(products, eq(users.id, products.user_id))
  return res.send(result);
});
//++++++++++++++++++++++++++++++++++++++++++
//Inner Join Partial Select
//++++++++++++++++++++++++++++++++++++++++++
app.get('/product-inner-join-select', async (req, res) => {
  const result = await db.select({
    userId: users.id,
    userFirstName: users.first_name,
    userLastName: users.last_name,
    products: products
  }).from(users).innerJoin(products, eq(users.id, products.user_id))
  return res.send(result);
});
//++++++++++++++++++++++++++++++++++++++++++
//INSERT
//++++++++++++++++++++++++++++++++++++++++++
app.post('/product-insert', async (req, res) => {
  const result = await db.insert(products).values({ 
    user_id : req.body.user_id,
    uuid : req.body.uuid,
    sku : req.body.sku,
    title : req.body.title,
    title_slug : req.body.title_slug,
    short_description : req.body.short_description,
    description : req.body.description,
    price : req.body.price,
    discounted_price : req.body.discounted_price,
    tag : req.body.tag,
    status : req.body.status,
    created_at : new Date(),
  });
  return res.send(result);
});
//++++++++++++++++++++++++++++++++++++++++++
//UPDATE
//++++++++++++++++++++++++++++++++++++++++++
app.post('/product-update', async (req, res) => {
  const result = await db.update(products).set({ 
    user_id : req.body.user_id,
    uuid : req.body.uuid,
    sku : req.body.sku,
    title : req.body.title,
    title_slug : req.body.title_slug,
    short_description : req.body.short_description,
    description : req.body.description,
    price : req.body.price,
    discounted_price : req.body.discounted_price,
    tag : req.body.tag,
    status : req.body.status,
    created_at : new Date(),
  }).where(eq(products.id, req.body.id));
  return res.send(result);
});
//++++++++++++++++++++++++++++++++++++++++++
//DELETE
//++++++++++++++++++++++++++++++++++++++++++
app.get('/product-delete', async (req, res) => {
  // await db.delete(products); // Delete ALL The Rows
  const result = await db.delete(products).where(eq(products.id, req.query.id));
  return res.send(result);
});
//++++++++++++++++++++++++++++++++++++++++++
//Server
//++++++++++++++++++++++++++++++++++++++++++
const PORT = process.env.PORT || 3000;
//++++++++++++++++++++++++++++++++++++++++++
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});

