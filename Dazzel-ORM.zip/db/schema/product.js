//++++++++++++++++++++++++++++++++++++++++++
//Inport
//++++++++++++++++++++++++++++++++++++++++++
const { int, varchar, text, datetime, decimal, mysqlTable, mysqlSchema } = require('drizzle-orm/mysql-core');
//++++++++++++++++++++++++++++++++++++++++++
// Blog Schema
//++++++++++++++++++++++++++++++++++++++++++
module.exports.products = mysqlTable('products', {
    id: int("id").primaryKey().autoincrement(),
    user_id: int('user_id').notNull().references(() => users.id),
    uuid: varchar('uuid', { length: 255 }),
    sku: varchar('sku', { length: 255 }),
    title: varchar('title', { length: 255 }),
    title_slug: varchar('title_slug', { length: 255 }),
    short_description: text('short_description'),
    description: text('description'),
    price: decimal('price', { precision: 10, scale: 2,}),
    discounted_price:  decimal('discounted_price', { precision: 10, scale: 2,}),
    tag: varchar('tag', { length: 255 }),
    status: int('status'),
    created_at: datetime('created_at'),
    updated_at: datetime('updated_at'),
});